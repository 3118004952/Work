#include<reg51.h>
#include <intrins.h>
#define unchar unsigned char
#define unint unsigned int

unchar aa;  //������ˮ�Ƶ�ѭ��
unchar code num[10] = {
0x3f, 0x06, 0x5b,
0x4f,0x66,0x6d,
0x7d, 0x07, 0x7f, 0x6f
};

sbit X = P1^0;//������

void delay(int z,int k);
void count(int num);

void main()
{
	int nums = 32688;
	aa = 0xfe;
	P0 = aa;
	X = 0;
	while(1)
	{
		if(nums == 32767)//int�����ֵ
			nums = 0;
	 	P0 = aa;
		aa = _crol_(aa, 1);//��ˮ��ѭ���õĺ���
		X = 0;
		delay(5, nums);	
		X = 1;
		delay(5, nums);
		nums++;
	}
}

void delay(int z,int nums)//�ӳټӼ�����
{
	unint i;
	for(i = 0; i < z; i++)
		count(nums);
}
void count(int z) //�������ĺ���
{
	int i;
	unchar choice = 0x20;
	for(i = 0; i < 1800; i++);
	P3 = 0xff;
	P2 = num[z % 10];
	P3 = ~choice;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	P3 = 0xff;
	P2 = num[z % 10];
	P3 = ~choice;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	P3 = 0xff;
	P2 = num[z % 10];
	P3 = ~choice;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	P3 = 0xff;
	P2 = num[z % 10];
	P3 = ~choice;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	P3 = 0xff;
	P2 = num[z % 10];
	P3 = ~choice;
	choice = choice >> 1;
	z /= 10;
}
