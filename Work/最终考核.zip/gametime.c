#include "head\errprom.h"
#include "head\gametime.h"

sbit whitch = P3^1;
sbit what = P3^0;


extern uc judge;//�ж����
extern int nums;//��ʾʱ��
uc code num[11] = {
0x3f, 0x06, 0x5b,
0x4f,0x66,0x6d,
0x7d, 0x07, 0x7f, 0x6f, 0x00
};

/**
 *    @name        	: void count(int a)
 *    @description  : ��������̬��ʾ����
 *    @param        ��int a  ��ʾ������
 *    @return      	: 
 */
void count(int a)
{
	int z = a;
	int i;
	uc choice = 0x20;
	for(i = 0; i < 1800; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	what = 1;
	P1 = num[z % 10];
	what = 0;
	whitch = 1;
	P1 = ~choice;
	whitch = 0;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	what = 1;
	P1 = num[z % 10];
	what = 0;
	whitch = 1;
	P1 = ~choice;
	whitch = 0;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	what = 1;
	P1 = num[z % 10];
	what = 0;
	whitch = 1;
	P1 = ~choice;
	whitch = 0;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	what = 1;
	P1 = num[z % 10];
	what = 0;
	whitch = 1;
	P1 = ~choice;
	whitch = 0;
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 1800; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	what = 1;
	P1 = num[z % 10];
	what = 0;
	whitch = 1;
	P1 = ~choice;
	whitch = 0;
	choice = choice >> 1;
	z /= 10;
}

/**
 *    @name        	: void TurnOn()
 *    @description  : ������ʱ��
 *    @param        ��
 *    @return      	: 
 */
void TurnOn()
{
	judge = 0;
	nums = 20;
	TH0 = (65536 - 40000) / 256;
	TL0 = (65536 - 40000) % 256;	
	TR0 = 1;
}

/**
 *    @name        	: void Suspend
 *    @description  : ��ͣ��������ʱ��
 *    @param        ��
 *    @return      	: 
 */
void Suspend()
{
	if(nums > 0)
		TR0 = ~TR0;
}


