#ifndef _MOVE_H_
#define _MOVE_H_

/**
 *    @name        : void TurnUp()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnUp();

/**
 *    @name        : void TurnDown()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnDown();

/**
 *    @name        : void TurnLeft()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnLeft();

/**
 *    @name        : void TurnRight()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnRight();

#endif