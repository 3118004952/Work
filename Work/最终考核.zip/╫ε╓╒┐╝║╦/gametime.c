#include "head\errprom.h"
#include "head\gametime.h"
#include "head\gamelcd.h"

sbit whitch = P3^1;
sbit what = P3^0;

extern uc judge;//�ж����
extern ui nums;//��ʾʱ��
extern ui alltime;//��ʱ��

uc code num[11] = {
0x3f, 0x06, 0x5b,
0x4f,0x66,0x6d,
0x7d, 0x07, 0x7f, 0x6f, 0x00
};

/**
 *    @name        	: void count(ui a, ui lefttime1)
 *    @description  : ��������̬��ʾ����  ʣ��ʱ��  �ܷ���  ����LCD��Ļ�ϵ���ʱ��
 *    @param        ��int a  ��ʾ������ ui lefttime1 ʣ��ʱ��
 *    @return      	: 
 */
void count(ui a, ui lefttime1)
{
	ui z = a, lefttime = lefttime1;
	ui i;
	uc choice = 0x80;
	if(judge <= 2 && TR0)
		PrinNumMessage(alltime , 1164);//ʣ��ʱ��
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(a >= 0)
	{
		what = 1;
		P1 = num[z % 10];//1
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(a >= 10)
	{
		what = 1;
		P1 = num[z % 10];//2
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
	choice = choice >> 1;
	z /= 10;
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(a >= 100)
	{
		what = 1;
		P1 = num[z % 10];//3
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
	choice = choice >> 1;
	z = z/10;
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(a >= 1000)
	{
		what = 1;
		P1 = num[z % 10];//4
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
	choice = choice >> 1;
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(lefttime1 >= 0)
	{
		what = 1;
		P1 = num[lefttime % 10];//1
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
	choice = choice >> 1;
	lefttime /= 10;
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(lefttime1 >= 10)
	{
		what = 1;
		P1 = num[lefttime % 10];//2
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
	choice = choice >> 1;
	lefttime /= 10;
	for(i = 0; i < 700; i++);
	whitch = 1;
	P1 = 0xff;
	whitch = 0;
	if(lefttime1 >= 100)
	{
		what = 1;
		P1 = num[lefttime % 10];//3
		what = 0;
		whitch = 1;
		P1 = ~choice;
		whitch = 0;
	}
}

/**
 *    @name        	: void TurnOn()
 *    @description  : ������ʱ��
 *    @param        ��
 *    @return      	: 
 */
void TurnOn()
{
	judge = 0;
	nums = time1;
	TH0 = (65536 - 40000) / 256;
	TL0 = (65536 - 40000) % 256;	
	TR0 = 1;
}



