#include <reg51.h>
#include<intrins.h>//����_nop_()����
#include "head\errprom.h"
#include "head\gametime.h"
#include "head\gamelcd.h"
#include "head\move.h"

sbit buzzer = P2^3;//������

extern uc code map[][121][17];
extern uc nowx, nowy, nowmap, gratechoice, nowgrate;//��Ϸ����

/**
 *    @name        : void TurnUp()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnUp()
{
	if(map[nowmap][nowy * 8][nowx] != 0xFF && map[nowmap][nowy * 8][nowx] != 0x7F && map[nowmap][nowy * 8][nowx] != 0xFE &&  map[nowmap][nowy * 8][nowx] != 0x7E )
	{
		nowy--;
		lcdcmd2(nowx, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}
/**
 *    @name        : void TurnDown()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnDown()
{
	if(map[nowmap][(nowy + 1) * 8][nowx] != 0xFF && map[nowmap][(nowy + 1) * 8][nowx] != 0x7F && map[nowmap][(nowy + 1) * 8][nowx] != 0xFE && map[nowmap][(nowy + 1) * 8][nowx] != 0x7E)
	{
		nowy++;
		lcdcmd2(nowx, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}

/**
 *    @name        : void TurnLeft()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnLeft()
{
	if(map[nowmap][nowy * 8 + 3][nowx] != 0x80)
	{
		nowx--;
		lcdcmd2(nowx, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}

/**
 *    @name        : void TurnRight()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnRight()
{
	if(map[nowmap][nowy * 8 + 3][nowx + 1] != 0x80)
	{
		nowx++;
		lcdcmd2(nowx, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}
