#include <reg51.h>
#include<intrins.h>//����_nop_()����
#include "head\errprom.h"
#include "head\gametime.h"
#include "head\gamelcd.h"
#include "head\move.h"

sbit buzzer = P2^3;//������

extern uc (*map)[17];
extern uc nowx, nowy, nowmap, gratechoice, nowgrate;//��Ϸ����

/**
 *    @name        : void TurnUp()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnUp()
{
	if(map[nowy * 8][nowx % 16] != 0xFF && map[nowy * 8][nowx % 16] != 0x7F && map[nowy * 8][nowx % 16] != 0xFE &&  map[nowy * 8][nowx % 16] != 0x7E )
	{
		nowy--;
		lcdcmd2(nowx % 16, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}
/**
 *    @name        : void TurnDown()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnDown()
{
	if(map[(nowy + 1) * 8][nowx % 16] != 0xFF && map[(nowy + 1) * 8][nowx % 16] != 0x7F && map[(nowy + 1) * 8][nowx % 16] != 0xFE && map[(nowy + 1) * 8][nowx % 16] != 0x7E)
	{
		nowy++;
		lcdcmd2(nowx % 16, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}

/**
 *    @name        : void TurnLeft()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnLeft()
{
	if(map[nowy * 8 + 3][nowx % 16] != 0x80)
	{
		nowx--;
		lcdcmd2(nowx % 16, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}

/**
 *    @name        : void TurnRight()
 *    @description :����
 *    @param       ��
 *    @notice      : None
 */
void TurnRight()
{
	if(map[nowy * 8 + 3][nowx % 16 + 1] != 0x80)
	{
		nowx++;
		lcdcmd2(nowx % 16, nowy, 0x21);
		buzzer = 0;
		Delay(1);
		buzzer = 1;
	}
}
