#include <reg51.h>
#include<intrins.h>//����_nop_()����
#include "head\errprom.h"
#include "head\gametime.h"
#include "head\gamelcd.h"
#include "head\move.h"

sbit p0 = P3^2;
sbit p1 = P3^3;
sbit p2 = P3^4;
sbit p = P3^5;
sbit buzzer = P2^3;

ui nowx = 0, nowy = 0, nowmap = 0, nowgrate = 0, nowstate = 0;//��Ϸ����
uc judge;//�ж����
int nums = time1;//��ʾʱ��


/**
 *    @name        	: char key()
 *    @description  : ��òٿص���Ϣ
 *    @param        ��
 *    @return      	: �����ı��
 */
char key()
{
	uc k = 0, i = 0;
	while(p);
	i = p2;
	k += i;
	i = 0;
	i = p1;
	k = k + i * 2;
	i = 0;
	i = p0;
	k = k + i * 4;
	p = 0;
	return k;
}

/**
 *    @name        	: void GetOperate(char datas)
 *    @description  : ���ݰ������в���
 *    @param        ��char datas  ������Ϣ
 *    @return      	: 
 */
void GetOperate(char datas)
{
	switch(datas)
	{
		case 1:
			if(nowstate == 1)
			{
				TurnUp();
			while(key() == 1)
					count(nums);
			}
			break;
		case 2:
			if(nowstate == 1)
				TurnLeft();
			while(key() == 2)
					count(nums);
			break;
		case 3:
			if(nowstate == 1)
			{	TurnDown();
				while(key() == 3)
					count(nums);
			}
			break;
		case 4:
			if(nowstate == 1)
			{
				TurnRight();
				while(key() == 4)
					count(nums);
			}
			break;
		case 5:			//��ʼ��Ϸ
			Delay(5);
			if(nums == time1)
			{
				if(key() == 5)
				{
					TurnOn();
					buzzer = 0;
					Delay(5);
					buzzer = 1;
					PrinMap(nowmap);//����ͼ
					PrinAllMessage(nowmap, nowgrate);//д��Ϣ
					nowstate = 1;
				}
				while(key() == 5)
					count(nums);
			}
			break;
		case 6:			//��ͣ��ʼ��ʱ��
			Delay(10);
			if(key() == 6)
			{
				if(nowstate == 1)//�ı䵱ǰ��״̬
					nowstate = 0;
				else
					nowstate = 1;
				if(nums > 0)//��ʼ����ͣ��ʱ��
					TR0 = ~TR0;
				buzzer = 0;
				Delay(5);
				buzzer = 1;
				while(key() == 6)
					count(nums);
			}
			break;
		case 7:
			break;
		default: ;
	
	}
}

int main()
{
	TMOD = 0x01;
	EA = 1;
	ET0 = 1;
	nums = 20;//��ʱ��
	lcdinit();
	nowy = 1; nowx = 1;
	while(1)
	{
		GetOperate(key());
		count(nums);
		if(nums == 0)//�жϳ�ʱ
		{
			nowstate = 0;
			TR0 = 0;
			nums = time1;
			judge = 0;
			nowx = 0;
			nowy = 0;
			nowstate = 0;
			nowmap = 0;
		}
		if(nowy == 15)//�жϹ���
		{
			nowstate = 0;
			TR0 = 0;
			nowgrate += nums;
			nums = time1;
			judge = 0;
			nowx = 0;
			nowy = 0;
			nowstate = 0;
			nowmap++;
		}
	}
}

/**
 *    @name        	: void interr() interrupt 1
 *    @description  : ��ʱ�����ж�
 *    @param        ��
 *    @return      	: 
 */
void interr() interrupt 1
{
	if(judge++ == 20)
	{
		nums--;
		if(nums == 0)
				TR0 = 0;
		judge = 0;
	}
	TH0 = (65536 - 40000) / 256;
	TL0 = (65536 - 40000) % 256;
}