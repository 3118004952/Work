#include <reg51.h>
#include<intrins.h>
#include "head\errprom.h"
#include "head\gametime.h"
#include "head\gamelcd.h"
#include "head\move.h"
#define plusgrate 30

sbit p0 = P3^2;//���ӵ�Ƭ��
sbit p1 = P3^3;
sbit p2 = P3^4;
sbit p = P3^5;
sbit buzzer = P2^3;//������

uc nowx = 0, nowy = 0, nowmap = 0, nowstate = 10, gratechoice = 1;//��Ϸ����
ui nowgrate = 0, alltime = 0;
uc judge;//�ж����
ui nums = time1;//��ʾʱ��

code uc heartplace[][2] = {
8, 6,
};

/**
 *    @name        	: char key()
 *    @description  : ��òٿص���Ϣ
 *    @param        ��
 *    @return      	: �����ı��
 */
uc key()
{
	uc k = 0, i = 0;
	while(p);
	i = p2;
	k += i;
	i = 0;
	i = p1;
	k = k + i * 2;
	i = 0;
	i = p0;
	k = k + i * 4;
	p = 0;
	return k;
}

/**
 *    @name        	: void GetOperate(char datas)
 *    @description  : ���ݰ������в���
 *    @param        ��char datas  ������Ϣ
 *    @return      	: 
 */
void GetOperate(uc datas, choice)
{
	switch(datas)
	{
		case 1://����
			if(nowstate == 1)
			{
				TurnUp();
				while(key() == 1)
					count(nowgrate, nums);
			}
			break;
		case 2://����
			if(nowstate == 1)
			{
				TurnLeft();
				while(key() == 2)
					count(nowgrate, nums);
			}
			break;
		case 3://����
			if(nowstate == 1)
			{	
				TurnDown();
				while(key() == 3)
					count(nowgrate, nums);
			}
			break;
		case 4://����
			if(nowstate == 1)
			{
				TurnRight();
				while(key() == 4)
					count(nowgrate, nums);
			}
			break;
		case 5:			//��ʼ��Ϸ
			Delay(5);
			if(nums == time1)
			{
				if(key() == 5)
				{
					TurnOn();
					CleanLcd(0, 30, 128);
					PrinAllMessage(nowmap, nowgrate);//д��Ϣ
					buzzer = 0;
					count(nowgrate, nums);
					buzzer = 1;
					PrinMap(nowmap, choice);//����ͼ
					Prinheart(heartplace[nowmap][0], heartplace[nowmap][1], gratechoice);
					nowx = 0;
					nowy = 0;
					lcdcmd2(nowx, nowy, 0x21);
					nowstate = 1;
					lcdcmd0(0x9d); //�����ʾ
				}
				while(key() == 5)
					count(nowgrate, nums);
			}
			break;
		case 6:			//��ͣ��ʼ��ʱ��
			if(nowstate < 10)
			{
				Delay(10);
				if(key() == 6)
				{
					if(nowstate == 1)//�ı䵱ǰ��״̬
						nowstate = 0;
					else
						nowstate = 1;
					if(nums > 0)//��ʼ����ͣ��ʱ��
						TR0 = ~TR0;
					buzzer = 0;
					count(nowgrate, nums);
					buzzer = 1;
					while(key() == 6)
						count(nowgrate, nums);
				}
			}
			break;
		case 7:
			break;
		default: ;
	
	}
	if(nowstate == 1 && gratechoice == 1 && nowx == heartplace[nowmap][0] && nowy == heartplace[nowmap][1])
	{
		gratechoice = 0;
		Prinheart(heartplace[nowmap][0], heartplace[nowmap][1], gratechoice);
		nowgrate += plusgrate;
	}
}

int main()
{
	uc save;
	TMOD = 0x01;
	EA = 1;
	ET0 = 1;
	nums = time1;//��ʱ��
	lcdinit();//��ʼ����Ļ����
	PrinStart();
	while(1)
	{
		GetOperate(key(), 0);
		count(nowgrate, nums);
		if(nowy > 14)//�жϹ���
		{
			gratechoice = 1;
			lcdcmd0(0x9c); //��겻��ʾ
			Success();
			nowstate = 10;
			TR0 = 0;
			nowgrate += nums;
			nums = time1;
			nowy = 0;
			nowmap++;
		}
		if(nums == 0)//�жϳ�ʱ
		{
			lcdcmd0(0x9c); //��겻��ʾ
			PrinNumMessage(nums, 1164);
			nowstate = 10;
			Fail();
			do
				save = key();
			while(save != 5 && save != 6);
			if(save == 5)//ѡ���ֵ
			{
				TR0 = 0;
				nums = time1;
				lcdcmd2(nowx, nowy, 0x21);
				GetOperate(5, 1);
			}
			else//���¿�ʼ��Ϸ
			{
				nums = time1;
				judge = 0;
				nowmap = 0;
				nowgrate = 0;
				PrinStart();
			}
		}
	}
}

/**
 *    @name        	: void interr() interrupt 1
 *    @description  : ��ʱ�����ж�
 *    @param        ��
 *    @return      	: 
 */
void interr() interrupt 1
{
	if(judge++ == 20)
	{
		nums--;
		alltime++;
		if(nums == 0)
				TR0 = 0;
		judge = 0;
	}
	TH0 = (65536 - 40000) / 256;
	TL0 = (65536 - 40000) % 256;
}