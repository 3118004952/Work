#include <stdio.h>
#include "c.h"
int main()
{
	All_User L;
	L = InitSystem();
	MenuAdmin(&L);
	return 0;
}
