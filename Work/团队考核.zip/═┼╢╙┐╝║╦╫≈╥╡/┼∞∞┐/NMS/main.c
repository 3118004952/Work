#include <stdio.h>
#include <stdlib.h>
#include "NoteManagementSystem.h"
#include "tag.h"

char rootpath[200];//�洢�û�·��         CurFloder *currentfile//�洢�ļ���Ϣ 
char currentpath[200];//�洢��ǰ·��

int main(void) 
{
	CurFloder *read;
	FOF *fofnext1, *fofnext2;
	Tag *tagnext1, *tagnext2;
	char s[] = "C:\Users\ChenYu\Desktop\NMS\����";
	char b[] = "C:\Users\ChenYu\Desktop\NMS\����";
	char c[] = "\\";
	
	char a[]="a2";
	char change[]="a2����change";
	
	strcpy(currentpath, s);
	strcpy(rootpath,b);
	read = (CurFloder *)malloc(sizeof(CurFloder));
	Read_Save(read, currentpath);//��ȡ��ǰĿ¼���ļ���Ϣ��read�� 
	fofnext1 = read->F;
	while(fofnext1 != NULL)//�����ǰ�ļ�����Ϣ 
	{
		printf("\n%d  %s  %d\n",fofnext1->flag, fofnext1->name, fofnext1->num);
		tagnext1 = fofnext1->taghead;
		while(tagnext1 != NULL)
		{
			printf("   %s   ", tagnext1->info);
			tagnext1= tagnext1->next;
		}
		fofnext1= fofnext1->next;
	}
	
	printf("\n\n");
	
	/*���ӱ�ǩ*/
	chdir(currentpath);//��ǰĿ¼ΪϵͳĿ¼���ı䵱ǰĿ¼Ϊ \���� 
	PrintAppointTag(read,a);
	printf("\n");
	AddAppointTag(read, a, change);
	printf("\n");
	PrintAppointTag(read,a);
	
	printf("\n\n");
	
	fofnext1 = read->F;
	while(fofnext1 != NULL)//�����ǰ�ļ�����Ϣ 
	{
		printf("\n%d  %s  %d\n",fofnext1->flag, fofnext1->name, fofnext1->num);
		tagnext1 = fofnext1->taghead;
		while(tagnext1 != NULL)
		{
			printf("   %s   ", tagnext1->info);
			tagnext1= tagnext1->next;
		}
		fofnext1= fofnext1->next;
	}
	
//	printf("\n\n");
//	/*ɾ����ǩ*/
//	chdir(currentpath);//��ǰĿ¼ΪϵͳĿ¼���ı䵱ǰĿ¼Ϊ \���� 
//	PrintAppointTag(read,a);
//	printf("\n");
//	DeleteAppointTag(read, a, change);
//	printf("\n");
//	PrintAppointTag(read,a);
//	
//	printf("\n\n");
//	
//	fofnext1 = read->F;
//	while(fofnext1 != NULL)//�����ǰ�ļ�����Ϣ 
//	{
//		printf("\n%d  %s  %d\n",fofnext1->flag, fofnext1->name, fofnext1->num);
//		tagnext1 = fofnext1->taghead;
//		while(tagnext1 != NULL)
//		{
//			printf("   %s   ", tagnext1->info);
//			tagnext1= tagnext1->next;
//		}
//		fofnext1= fofnext1->next;
//	}
	
//	printf("\n%s\n",currentpath);
	getchar();

	return 0;
}
