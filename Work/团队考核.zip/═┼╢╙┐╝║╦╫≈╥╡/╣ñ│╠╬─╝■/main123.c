#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "..\head\NoteManagementSystem.h"
#include "..\head\chenyu.h" 


