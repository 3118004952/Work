#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "..\head\NoteManagementSystem.h"
#include "..\head\chenyu.h" 

char rootpath[200];//�洢�û�·��         CurFloder *currentfile
char currentpath[200];//�洢��ǰ·��

int main()
{
	
	User name;
	char s[20] = "D:\\����";
	char b[20] = "D:\\����";
	strcpy(currentpath, s);
	strcpy(rootpath,b);
	SecondMain(name);
}
/*
	SearchTag("", rootpath, &sum);
	printf("\n�����������ļ�����Ϊ��%d\n", sum);*/
/*
	Read_Save(read, s);
	Input_Save(read, s);
	fofnext1 = read->F;
while(fofnext1 != NULL)
	{
		printf("\n%d  %s  %d\n",fofnext1->flag, fofnext1->name, fofnext1->num);
		tagnext1 = fofnext1->taghead;
		while(tagnext1 != NULL)
		{
			printf("   %s   ", tagnext1->info);
			tagnext1= tagnext1->next;
		}
		fofnext1= fofnext1->next;
	}
	DestroyFof(read);
	fofnext1 = read->F;
	printf("\n111\n");
	while(fofnext1 != NULL)
	{
		printf("\n%d  %s  %d\n",fofnext1->flag, fofnext1->name, fofnext1->num);
		tagnext1 = fofnext1->taghead;
		while(tagnext1 != NULL)
		{
			printf("   %s   ", tagnext1->info);
			tagnext1= tagnext1->next;
		}
		fofnext1= fofnext1->next;
	}
	getchar();*/
