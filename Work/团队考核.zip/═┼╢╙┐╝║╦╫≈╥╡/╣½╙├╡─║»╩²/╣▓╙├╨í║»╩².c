#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../head/NoteManagementSystem.h"

extern char rootpath[];//�洢�û�·��         CurFloder *currentfile
extern char currentpath[];//�洢��ǰ·��

/**
 *  @name        : Status RoteExistence(const char *s, int choice)
 *  @description : ������·�����Ƿ�����ļ��л�txt�ļ� ��Ҳ���������ж�·�������Ƿ���ȷ 
 *  @param       : const char *s ����ľ���·��    choice 0��ʾ�ж��ļ��д������   ��'0'��ʾtxt�ļ��������
 *  @return      : SUCCESS ��ʾ����      ERROR��ʾ������ 
 */
Status RoteExistence(const char *s, int choice)
{
	FILE *w;
	char a[200];
	char b[] = "\\_save.txt";
	strcpy(a, s);
	if(choice == 0)//����������� ���� ���Ŀ¼�Ƿ���� 
	{
		strcat(a, b);//������ļ��У���ô�ļ����ڿ϶����ڱ������ݵ�txt�ļ����Դ˼����Ƿ�����ļ���
	}	//������������if��䣬�����ı��ļ��Ƿ���ڣ������������ 
	w = fopen(a, "r");
	if(w == NULL)
	{
		fclose(w);
		return ERRORS;
	}
	fclose(w);
	return SUCCESS;
}

 /**
 *  @name        : void Input_Save(CurFloder *input)
 *  @description : ���ļ�����Ϣ¼��_save.txt �ļ� 
 *  @param       : CurFloder char *input   �����ļ���Ϣ�����ĵĽṹ��
 *                 const char *filerote    Ҫ������Ŀ¼��·�������ü�_save.txt���������Զ�����_save.txt,ֻҪ��Ŀ¼��·���� 
 *  @return      : 
 */
void Input_Save(CurFloder *input, const char *filerote)
{
	FILE *w;
	char copyfilerote[200];
	char a[] = "\\_save.txt";
	FOF *fofnext;
	Tag *tagnext;
	int tagnum;
	fofnext = input->F;
	strcpy(copyfilerote, filerote);//���ƻ�õ�·�� 
	strcat(copyfilerote, a);//��·�������_save.txt����ļ��� 
	w = fopen(copyfilerote, "w");
	if(w == NULL)
	{
		printf("�ļ�<%s>��ʧ��",filerote); 
		exit(0);
	}
	while(fofnext != NULL)
	{
		fprintf(w, "%d %s %d \n", fofnext->flag, fofnext->name, fofnext->num);
		tagnum = fofnext->num;
		if(tagnum > 0)
		{
			tagnext = fofnext->taghead;
			while(tagnum > 0)
			{
				fprintf(w, "   %s   ", tagnext->info);
				tagnext = tagnext->next;
				tagnum--;
			}
			fprintf(w, "\n");
		}
		fofnext = fofnext->next;
	}
	fclose(w);
}

/**
 *  @name        : void Read_Save(CurFloder *read, const char *filerote)
 *  @description : ��_save.txt ��ȡ�ļ�����Ϣ
 *  @param       : CurFloder *read   
 *                  �����ļ���Ϣ�Ľṹ�壨Ҫ�ں���ǰ��malloc������ڴ�����ã�
 *                 const char *filerote    Ŀ¼��·�������ü�_save.txt���������Զ�����_save.txt��
 *  @return      : 
 */	
void Read_Save(CurFloder *read, const char *filerote)
{										
	FILE *r;
	char rotecopy[200];
	char a[20] = "\\_save.txt";
	FOF *fofnext1, *fofnext2;
	Tag *tagnext1, *tagnext2;
	int tagnum;
	int filesum = 0;
	strcpy(rotecopy, filerote);
	strcat(rotecopy, a);
	r = fopen(rotecopy, "r");
	if(r == NULL)
	{
		printf("�ļ�<%s>��ʧ��",filerote); 
		exit(0);
	}
	fofnext1 = fofnext2 = (FOF *)malloc(sizeof(FOF));
	read->F = fofnext1;
	while(EOF != fscanf(r, "%d%s%d", &fofnext2->flag, fofnext2->name, &fofnext2->num))
	{
		filesum++;
		if(filesum != 1)
		{
			fofnext1->next = fofnext2;
			fofnext1 = fofnext2;
		}
		fofnext2 = (FOF *)malloc(sizeof(FOF));
		if(fofnext1->num > 0)
		{	
			tagnum = 0;
			while(tagnum < fofnext1->num)
			{
				tagnum++;
				tagnext2 = (Tag *)malloc(sizeof(Tag));
				fscanf(r, "%s", tagnext2->info);
				if(tagnum == 1)
				{
					tagnext1 = tagnext2;
					fofnext1->taghead = tagnext1;
				}	
				else
				{
					tagnext1->next = tagnext2;
					tagnext1 = tagnext2;
				}
			}
			tagnext1->next = NULL;
		}
		else
		{
			fofnext1->taghead = NULL;
		}
	}
	free(fofnext2);
	if(filesum == 0)
	{
		read->F = NULL;
	}
	else
	{
		fofnext1->next = NULL;
	}
	fclose(r);
}

/**
 *  @name        : void DestroyFof(CurFloder *des)
 *  @description : �������� 
 *  @param       :  CurFloder *des   �����ļ���Ϣ�Ľṹ�壨Ҫ�ں���ǰ��malloc������ڴ�����ã�
 */	
void DestroyFof(CurFloder *des)
{
	FOF *fofdes1, *fofdes2;
	Tag *tagdes1, *tagdes2;
	fofdes1 = des->F;
	while(fofdes1 != NULL)
	{
		tagdes1 = fofdes1->taghead;
		while(tagdes1 != NULL)
		{
			tagdes2 = tagdes1->next;
			free(tagdes1);
			tagdes1 =tagdes2;
		}
		fofdes2 = fofdes1->next;
		free(fofdes1);
		fofdes1 = fofdes2;
	} 
	des->F = NULL;
}

/**
 *  @name        : vvoid SecondMain()
 *  @description : �൱�ڵڶ��������� 
 *  @param       : 
 */	
void SecondMain(User name)
{
	CurFloder *head;
	char copychar[400];
	char inputmessage[400];
	char firstmessage[400], secondmessage[400];
	int savesum, userchoice, length;
	int i, j;
	head = (CurFloder *)malloc(sizeof(CurFloder));
	Read_Save(head, currentpath);
	for(i = 0; rootpath[i] != '\0'; i++)//�ҵ����һ��б�� 
	{
		if(rootpath[i] == '\\')
			length = i;
	}
	while(1)
	{
		setColor(3,0);
		printf("\n%s   ", name.name);
		setColor(12,0);
		for(i = 0; i < length; i++)
			printf("%c", currentpath[i]);
		setColor(14,0);
		for(i; currentpath[i] != '\0'; i++)
			printf("%c", currentpath[i]);
		setColor(15,0);
		printf("\n�� ");
		gets(inputmessage);
		for(i = 0; inputmessage[i] == ' ' && inputmessage[i] != '\0'; i++);
			savesum = i;
		for(i = savesum; inputmessage[i] != '\0'; i++)
			copychar[i - savesum] = inputmessage[i];
		copychar[i - savesum] = '\0';
		if(copychar[0] == 'l' && copychar[1] == 's')//ls
		{
			for(i = 2; copychar[i] == ' ' && copychar[i] != '\0'; i++);
			if(copychar[i] != '\0')
			{
				if(copychar[i] == '-' && copychar[i + 1] == 'a' && (copychar[i + 2] == ' ' || copychar[i + 2] == '\0'))
				{
					for(i += 2; copychar[i] == ' ' && copychar[i] != '\0'; i++);
					if(copychar[i] == '\0')
					{
						userchoice = 2;
					}	
					else
					{
						printf("\n����ָ�����");
						continue;
					}
				}
				else
				{
					j = i;
					for(i; copychar[i] != ' ' && copychar[i] != '\0'; i++)
					{
						firstmessage[i - j] = copychar[i];
					}
					firstmessage[i - j] = '\0';
					for(i; copychar[i] == ' ' && copychar[i] != '\0'; i++);
					if(copychar[i] == '\0')
					{
						userchoice = 3;
					}
					else
					{
						if(copychar[i] == 'g' && copychar[i + 1] == 'r' && copychar[i + 2] == 'e' && copychar[i + 3] == 'p' && copychar[i + 4] == ' ')
						{
							for(i += 5; copychar[i] == ' ' && copychar[i] != '\0'; i++);
							j = i;
							if(copychar[i] != '\0')
							{
								for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
								{
									secondmessage[i - j] = copychar[i];
								}
								secondmessage[i - j] = '\0';
								if(copychar[i] != ' ')
									userchoice = 4;
								else
								{
									printf("\n����ָ�����");
									continue;
								}
							}
							else
							{
								printf("\n����ָ�����");
								continue;
							}
						}
						else
						{
							printf("\n����ָ�����");
							continue;
						}
					}
				}
			}
			else
			{
				userchoice = 1;
			}	
		}
		else
			if(copychar[0] == 'c' && copychar[1] == 'd')//cd
			{
				if(copychar[2] == '.' && copychar[3] == '.')
				{
					for(i = 4; copychar[i] != '\0' && copychar[i] == ' '; i++);
					if(copychar[i] == '\0')
						userchoice = 5;
					else
					{
						printf("\n����ָ�����");
						continue;
					}
				}
				else
				{
					for(i = 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
					if(copychar[i] != '\0')
					{
						j = i;
						for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
							firstmessage[i - j] = copychar[i];
						firstmessage[i - j] = '\0';
						for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);	
						if(copychar[i] == '\0')
							userchoice = 6;
						else
						{
							printf("\n����ָ�����");
							continue;
						}
					}
					else
					{
						printf("\n����ָ�����");
						continue;
					}
				}
			}
			else
				if(copychar[0] == 'm' && copychar[1] == 'v' && copychar[2] == ' ')//mv
				{
					for(i = 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
					if(copychar[i] == '-' && copychar[i + 1] == 'r' && (copychar[i + 2] == ' ' || copychar[i + 2] == '\0'))
					{
						for(i += 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
						j = i;
						for(i; copychar[i] != ' ' && copychar[i] != '\0'; i++)
							firstmessage[i - j] = copychar[i];
						firstmessage[i - j] = '\0';
						for(i; copychar[i] == ' ' && copychar[i] != '\0'; i++);
						j = i;
						for(i; copychar[i] != ' ' && copychar[i] != '\0'; i++)
							secondmessage[i - j] = copychar[i];
						secondmessage[i - j] = '\0';
						if(i == j)
						{
							printf("\n����ָ�����");
							continue;
						}
						for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
						if(copychar[i] == '\0')
							userchoice = 9;
						else
						{
							printf("\n����ָ�����");
							continue;
						}
					}
					else
					{
						if(copychar[i] != '\0')
						{
							j = i;
							for(i; copychar[i] != ' ' && copychar[i] != '\0'; i++)
								firstmessage[i - j] = copychar[i];
							firstmessage[i - j] = '\0';
							for(i; copychar[i] == ' ' && copychar[i] != '\0'; i++);
							j = i;
							for(i; copychar[i] != ' ' && copychar[i] != '\0'; i++)
								secondmessage[i - j] = copychar[i];
							secondmessage[i - j] = '\0';
							if(i == j)
							{
								printf("\n����ָ�����");
								continue;
							}
							j = i - j;
							for(i; copychar[i] == ' ' && copychar[i] != '\0'; i++);
							if(copychar[i] == '\0')
							{
								if(secondmessage[j - 1] == 't' && secondmessage[j - 2] == 'x' && secondmessage[j - 3] == 't' &&secondmessage[j - 4] == '.' && (secondmessage[j - 5] != '\0' || secondmessage[j - 5] != ' ') && j - 5 >= 0)
								{
									userchoice = 8;
								}
								else
									userchoice = 7;
							}
							else
							{
								printf("\n����ָ�����");
								continue;
							}
						}
						else
						{
							printf("\n����ָ�����");
							continue;
						}
					}
				}
				else 
					if(copychar[0] == 'r' && copychar[1] == 'm' && copychar[2] == ' ' )//rm
					{
						for(i = 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
						if(copychar[i] == '-' && copychar[i + 1] == 'r' && (copychar[i + 2] == ' ' || copychar[i + 2] == '\0'))
						{
							for(i += 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
							j = i;
							for(i; copychar[i] != ' ' && copychar[i] != '\0'; i++)
								firstmessage[i - j] = copychar[i];
							firstmessage[i - j] = '\0';
							if(i == j)
							{
								printf("\n����ָ�����");
								continue;
							}
							for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
							if(copychar[i] == '\0')
								userchoice = 11;
							else
							{
								printf("\n����ָ�����");
								continue;
							}
						}
						else
						{
							j = i;
							for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
							{
								firstmessage[i - j] = copychar[i];
							}
							firstmessage[i - j] = '\0';
							if(i == j)
							{
								printf("\n����ָ�����");
								continue;
							}
							for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
							if(copychar[i] == '\0')
								userchoice = 10;
							else
							{
								printf("\n����ָ�����");
								continue;
							}
						}
					}
					else
						if(copychar[0] == 't' && copychar[1] == 'a' && copychar[2] == 'g' && copychar[3] == ' ')//tag
						{
							for(i = 3; copychar[i] != '\0' && copychar[i] == ' '; i++);
							if(copychar[i] != '\0')
							{
								for(j = i; copychar[j] != '\0' && copychar[j] != ' '; j++);
								for(j = i; copychar[j] != '\0' && copychar[j] == ' '; j++);
								if(copychar[j] == '\0')
								{
									printf("\n����ָ�����");
									continue;
								}
								if(copychar[i] == '-' && copychar[i + 1] == 'a' && copychar[i+ 2] == 'd' && copychar[i + 3] == 'd' && copychar[i + 4] == ' ' )
								{
									for(i += 4; copychar[i] != '\0' && copychar[i] == ' '; i++);
									j = i;
									for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
										firstmessage[i - j] = copychar[i];
									firstmessage[i - j] = '\0';
									for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
									j = i;
									for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
										secondmessage[i - j] = copychar[i];
									secondmessage[i - j] = '\0';
									if(i == j)
									{
										printf("\n����ָ�����");
										continue;
									}
									for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
									if(copychar[i] == '\0')
										userchoice = 13;
									else
									{
										printf("\n����ָ�����");
										continue;
									}
									
								}
								else
									if(copychar[i] == '-' && copychar[i + 1] == 'd' && copychar[i+ 2] == 'e' && copychar[i + 3] == 'l' && copychar[i + 4] == ' ' )
									{
										for(i += 4; copychar[i] != '\0' && copychar[i] == ' '; i++);
										j = i;
										for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
											firstmessage[i - j] = copychar[i];
										firstmessage[i - j] = '\0';
										for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
										j = i;
										for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
											secondmessage[i - j] = copychar[i];
										secondmessage[i - j] = '\0';
										if(i == j)
										{
											printf("\n����ָ�����");
											continue;
										}
										for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
										if(copychar[i] == '\0')
											userchoice = 14;
										else
										{
											printf("\n����ָ�����");
											continue;
										}
									}
									else
										if(copychar[i] == '-' && copychar[i + 1] == 's' && copychar[i + 2] == ' ' )
										{
											for(i += 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
											j = i;
											for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
												firstmessage[i - j] = copychar[i];
											firstmessage[i - j] = '\0';
											for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
											if(copychar[i] == '\0')
												userchoice = 15;
											else
											{
												printf("\n����ָ�����");
												continue;
											}
										}
										else
											if(copychar[i] == '-' && copychar[i + 1] == 's' && copychar[i + 2] == 'a' && copychar[i + 3] == ' ')
											{
												for(i += 3; copychar[i] != '\0' && copychar[i] == ' '; i++);
												j = i;
												for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
													firstmessage[i - j] = copychar[i];
												firstmessage[i - j] = '\0';
												for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
												if(copychar[i] == '\0')
													userchoice = 16;
												else
												{
													printf("\n����ָ�����");
													continue;
												}
											}
											else
											{
												j = i;
												for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
													firstmessage[i - j] = copychar[i];
												firstmessage[i - j] = '\0';
												for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
												if(copychar[i] == '\0')
													userchoice = 12;
												else
												{
													printf("\n����ָ�����");
													continue;
												}
											}
							}
							else
							{
								printf("\n����ָ�����");
								continue;	
							}
							
						}
						else
							if(copychar[0] == 'm' && copychar[1] == 'd' && copychar[2] == ' ')
							{
								for(i = 2; copychar[i] != '\0' && copychar[i] == ' '; i++);
								j = i;
								for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
									firstmessage[i - j] = copychar[i];
								firstmessage[i - j] = '\0';
								if(i == j)
								{
									printf("\n����ָ�����");
									continue;
								}
								for(i; copychar[i] != '\0' && copychar[i] == ' '; i++);
								if(copychar[i] == '\0')
								{
									userchoice = 17;
								}
								else
								{
									printf("\n����ָ�����");
									continue;
								}
							}
							else
								if(copychar[0] == 's' && copychar[1] == 'o' && copychar[2] == 'r' && copychar[3] == 't')
								{
									
									for(i = 4; copychar[i] == ' ' && copychar[i] != '\0'; i++);
									j = i;
									for(i; copychar[i] != '\0' && copychar[i] != ' '; i++)
										firstmessage[i - j] = copychar[i];
									firstmessage[i - j] = '\0';
									for(i; copychar[i] == ' ' && copychar[i] != '\0'; i++);
									if(copychar[i] == '\0')
										userchoice = 18;
									else
									{
										printf("\n����ָ�����");
										continue;
									}
								}
								else
								{
									printf("\n����ָ�����");
									continue;
								}
		switch(userchoice)
		{
			case 1:
				
				break;
			case 2:
				
				break;
			case 3:
				
				break;
			case 4:
				
				break;
			case 5:
				CdReturn(head);
				break;
			case 6:
				CdSwitch(head, firstmessage);
				break;
			case 7:
				
				break;
			case 8:
				MVRename(head, firstmessage, secondmessage);
				break;
			case 9:
				
				break;
			case 10:
				
				break;
			case 11:
				
				break;
			case 12:
				
				break;
			case 13:
				
				break;
			case 14:
				
				break;
			case 15:
				
				break;
			case 16:
				savesum = 0;
				SearchTag(firstmessage, rootpath, &savesum);
				printf("\n���������ı�ǩ����Ϊ��%d",savesum);
				break;
			case 17:
				
				break;
			case 18:
				FileSort(firstmessage, currentpath);
				break;
			default : ;
		}		
		printf("%s",head->F->name);
	}
	
}















