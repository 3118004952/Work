#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include "../inc/qgsort.h"

int main()
{
	FILE *r;
	int max ;
	int i = 0;
	int num = 10;
	int temp[200000],a[200000];
	double run_time;
	LARGE_INTEGER time_start;	//��ʼʱ��
	LARGE_INTEGER time_over;	//����ʱ��
	double dqFreq;		//��ʱ��Ƶ��
	LARGE_INTEGER f;	//��ʱ��Ƶ��
	QueryPerformanceFrequency(&f);
	dqFreq=(double)f.QuadPart;
	r = fopen("data.txt","rb");
	if(r == NULL)
	{
		printf("\n\n\t\t\t���ļ�ʧ�ܣ�"); 
		printf("\n\n\t\t\t");
		system("pause");
		return 0;
	}
	fscanf(r,"%d",&max);
	for(i = 0; i < max; i++)
	{
		fscanf(r,"%d",&a[i]);
	}
	
	//���в�������ע�͵������Խ⿪ע��һ��һ���鿴 
/*	printf("\n\t\t\t��������\n");
	QueryPerformanceCounter(&time_start);
	insertSort(a,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	insertSort(a,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	insertSort(a,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	printf("\n\t\t\t�鲢����\n");
	QueryPerformanceCounter(&time_start);
	MergeSort(a,0,10000,temp);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	MergeSort(a,0,50000,temp);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	MergeSort(a,0,200000,temp);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	printf("\n\t\t\t��������ݹ�棺\n");
	QueryPerformanceCounter(&time_start);
	QuickSort_Recursion(a,0,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	QuickSort_Recursion(a,0,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	QuickSort_Recursion(a,0,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	printf("\n\t\t\t��������ǵݹ�棺\n");
	QueryPerformanceCounter(&time_start);
	QuickSort(a,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	QuickSort(a,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	QuickSort(a,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	printf("\n\t\t\t��������\n");
	QueryPerformanceCounter(&time_start);
	CountSort(a,10000,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	CountSort(a,50000,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	CountSort(a,200000,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	printf("\n\t\t\t������������\n");
	QueryPerformanceCounter(&time_start);
	RadixCountSort(a,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	RadixCountSort(a,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	RadixCountSort(a,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	printf("\n\t\t\t�ҵ�����С������\n");
	QueryPerformanceCounter(&time_start);
	FindThird(a,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	FindThird(a,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	FindThird(a,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);
	r = fopen("colordata.txt","rb");
	if(r == NULL)
	{
		printf("���ļ�ʧ�ܣ�"); 
		return 0;
	}
	fscanf(r,"%d",&max);
	for(i = 0; i < max; i++)
	{
		fscanf(r,"%d",&a[i]);
	}
	printf("\n\t\t\t��ɫ����\n");
	QueryPerformanceCounter(&time_start);
	ColorSort(a,10000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t10000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	ColorSort(a,50000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t50000:%fus",run_time);
	QueryPerformanceCounter(&time_start);
	ColorSort(a,200000);
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\t200000:%fus",run_time);/**/ */
	printf("\n\n\t\t\t");
	system("pause");
}
