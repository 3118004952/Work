#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include "../inc/qgsort.h"

int main()
{
	FILE *r;
	int max ;
	int i = 0;
	int num = 100000;
	int temp[100],a[100];
	double run_time;
	LARGE_INTEGER time_start;	//��ʼʱ��
	LARGE_INTEGER time_over;	//����ʱ��
	double dqFreq;		//��ʱ��Ƶ��
	LARGE_INTEGER f;	//��ʱ��Ƶ��
	QueryPerformanceFrequency(&f);
	dqFreq=(double)f.QuadPart;
	r = fopen("data.txt","rb");
	if(r == NULL)
	{
		printf("\n\n\t\t\t���ļ�ʧ�ܣ�"); 
		printf("\n\n\t\t\t");
		system("pause");
		return 0;
	}
	fscanf(r,"%d",&max); 
	for(i = 0; i < max; i++)
	{
		fscanf(r,"%d",&a[i]);
	}
	printf("\n\t\t\t100����*100000\n");
	printf("\n\t\t\t��������\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		insertSort(a,100);
	} 
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺%fus\n\n",run_time);
	printf("\n\t\t\t�鲢����\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		MergeSort(a,0,100,temp);
	}
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺%fus\n\n",run_time);
	printf("\n\t\t\t��������ݹ�棺\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		QuickSort_Recursion(a,0,100);
	}
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺%fus\n\n",run_time);
	printf("\n\t\t\t��������ǵݹ�棺\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		QuickSort(a,100);
	}
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺:%fus\n\n",run_time);
	printf("\n\t\t\t��������\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		CountSort(a,100,100);
	}
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺:%fus\n\n",run_time);
	printf("\n\t\t\t������������\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		RadixCountSort(a,100);
	}
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺%fus\n\n",run_time);
	r = fopen("colordata.txt","rb");
	if(r == NULL)
	{
		printf("���ļ�ʧ�ܣ�"); 
		return 0;
	}
	fscanf(r,"%d",&max);
	for(i = 0; i < max; i++)
	{
		fscanf(r,"%d",&a[i]);
	}
	printf("\n\t\t\t��ɫ����\n");
	QueryPerformanceCounter(&time_start);
	i = 0;
	while(i < num)
	{
		i++; 
		ColorSort(a,100);
	}
	QueryPerformanceCounter(&time_over);
	run_time=1000000*(time_over.QuadPart-time_start.QuadPart)/dqFreq;
	printf("\n\t\t\tʱ�䣺%fus\n\n",run_time);
	printf("\n\n\t\t\t");
	system("pause");
}
